#!/usr/bin/env python3
"""Run after `npx cap add android`.

1. Drops the native Gallery plugin into the generated Android project.
2. Adds the photo/video library permissions.
3. Locks the app down: no internet permission (so Android itself blocks every
   network connection), no cloud backups, no cleartext traffic.
"""
import pathlib
import re
import shutil
import sys

root = pathlib.Path(__file__).resolve().parent.parent
android = root / "android"
native = root / "native"

mains = list(android.glob("app/src/main/java/**/MainActivity.java"))
if not mains:
    sys.exit("MainActivity.java not found. Did `npx cap add android` run?")
pkg_dir = mains[0].parent
print("Java package folder:", pkg_dir)

for name in ("GalleryPlugin.java", "MainActivity.java"):
    shutil.copy(native / name, pkg_dir / name)
    print("copied", name)

manifest = android / "app/src/main/AndroidManifest.xml"
text = manifest.read_text()

# 1. take out any network permission the template added
text = "\n".join(
    line
    for line in text.split("\n")
    if not (
        re.search(r'android\.permission\.(INTERNET|ACCESS_NETWORK_STATE)"', line)
        and 'tools:node="remove"' not in line
    )
)

# 2. make sure no library can add the network permissions back during the manifest merge
if "xmlns:tools=" not in text:
    text = text.replace("<manifest ", '<manifest xmlns:tools="http://schemas.android.com/tools" ', 1)

perms = """    <!-- Photo and video library -->
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_VISUAL_USER_SELECTED" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />

    <!-- No network access, ever: these remove the permissions even if a library asks for them -->
    <uses-permission android:name="android.permission.INTERNET" tools:node="remove" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" tools:node="remove" />

"""
if "READ_MEDIA_IMAGES" not in text:
    text = re.sub(r"^[ \t]*<application", lambda m: perms + m.group(0), text, count=1, flags=re.M)


# 3. no backups to the cloud or to another phone, and no plain http
def set_attr(doc, name, value):
    m = re.search(r"<application\b[^>]*>", doc, re.S)
    if not m:
        sys.exit("<application> tag not found in AndroidManifest.xml")
    tag = m.group(0)
    if re.search(re.escape(name) + r'="[^"]*"', tag):
        new = re.sub(re.escape(name) + r'="[^"]*"', '%s="%s"' % (name, value), tag)
    else:
        new = tag[:-1].rstrip() + ' %s="%s">' % (name, value)
    return doc.replace(tag, new, 1)


text = set_attr(text, "android:allowBackup", "false")
text = set_attr(text, "android:usesCleartextTraffic", "false")

manifest.write_text(text)

# final check: refuse to continue if a network permission is still declared without the removal marker
for line in text.splitlines():
    if re.search(r"android\.permission\.(INTERNET|ACCESS_NETWORK_STATE)", line) and "tools:node=\"remove\"" not in line:
        sys.exit("Network permission still declared: " + line.strip())

print("manifest hardened. Permissions declared:")
for p in re.findall(r'<uses-permission[^>]*android:name="([^"]+)"[^>]*/>', text):
    print("  ", p)
