package com.kuha.gallery;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Size;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.IntentSenderRequest;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Reads the phone's photo and video library through MediaStore.
 * Ids look like "i123" (image) or "v456" (video).
 */
@CapacitorPlugin(
    name = "Gallery",
    permissions = {
        @Permission(
            alias = "media34",
            strings = {
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"
            }
        ),
        @Permission(
            alias = "media33",
            strings = {
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO
            }
        ),
        @Permission(
            alias = "media",
            strings = { Manifest.permission.READ_EXTERNAL_STORAGE }
        )
    }
)
public class GalleryPlugin extends Plugin {

    private final ExecutorService pool = Executors.newFixedThreadPool(3);

    // ---------- permission ----------

    private boolean granted(String permission) {
        return ContextCompat.checkSelfPermission(getContext(), permission) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (granted(Manifest.permission.READ_MEDIA_IMAGES) || granted(Manifest.permission.READ_MEDIA_VIDEO)) {
                return true;
            }
            // Android 14+: the person chose "Select photos and videos" only.
            return Build.VERSION.SDK_INT >= 34 && granted("android.permission.READ_MEDIA_VISUAL_USER_SELECTED");
        }
        return granted(Manifest.permission.READ_EXTERNAL_STORAGE);
    }

    private String accessAlias() {
        if (Build.VERSION.SDK_INT >= 34) return "media34";
        if (Build.VERSION.SDK_INT >= 33) return "media33";
        return "media";
    }

    @PluginMethod
    public void checkAccess(PluginCall call) {
        JSObject o = new JSObject();
        o.put("granted", hasAccess());
        call.resolve(o);
    }

    @PluginMethod
    public void requestAccess(PluginCall call) {
        if (hasAccess()) {
            checkAccess(call);
            return;
        }
        requestPermissionForAlias(accessAlias(), call, "accessCallback");
    }

    @PermissionCallback
    private void accessCallback(PluginCall call) {
        checkAccess(call);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.fromParts("package", getContext().getPackageName(), null));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("settings_failed");
        }
    }

    // ---------- listing ----------

    @PluginMethod
    public void list(final PluginCall call) {
        if (!hasAccess()) {
            call.reject("no_access");
            return;
        }
        pool.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    JSArray out = new JSArray();
                    query(out, false);
                    query(out, true);
                    JSObject res = new JSObject();
                    res.put("items", out);
                    call.resolve(res);
                } catch (Exception e) {
                    call.reject("list_failed: " + e.getMessage());
                }
            }
        });
    }

    private void query(JSArray out, boolean video) {
        Uri collection = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        List<String> cols = new ArrayList<String>(Arrays.asList(
            "_id", "_display_name", "datetaken", "date_added", "width", "height",
            "_size", "bucket_display_name", "_data", "mime_type"
        ));
        if (video) cols.add("duration");

        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(
                collection, cols.toArray(new String[0]), null, null, "date_added DESC"
            );
            if (c == null) return;
            int iId = c.getColumnIndex("_id");
            int iName = c.getColumnIndex("_display_name");
            int iTaken = c.getColumnIndex("datetaken");
            int iAdded = c.getColumnIndex("date_added");
            int iW = c.getColumnIndex("width");
            int iH = c.getColumnIndex("height");
            int iSize = c.getColumnIndex("_size");
            int iBucket = c.getColumnIndex("bucket_display_name");
            int iData = c.getColumnIndex("_data");
            int iMime = c.getColumnIndex("mime_type");
            int iDur = video ? c.getColumnIndex("duration") : -1;

            while (c.moveToNext()) {
                long id = c.getLong(iId);
                long taken = iTaken >= 0 ? c.getLong(iTaken) : 0;
                long added = iAdded >= 0 ? c.getLong(iAdded) : 0;
                long ts = taken > 0 ? taken : added * 1000L;

                JSObject o = new JSObject();
                o.put("id", (video ? "v" : "i") + id);
                o.put("kind", video ? "video" : "photo");
                o.put("name", iName >= 0 ? c.getString(iName) : "");
                o.put("ts", ts);
                o.put("w", iW >= 0 ? c.getInt(iW) : 0);
                o.put("h", iH >= 0 ? c.getInt(iH) : 0);
                o.put("size", iSize >= 0 ? c.getLong(iSize) : 0L);
                o.put("album", iBucket >= 0 ? c.getString(iBucket) : "");
                o.put("path", iData >= 0 ? c.getString(iData) : "");
                o.put("mime", iMime >= 0 ? c.getString(iMime) : "");
                if (video && iDur >= 0) o.put("dur", c.getLong(iDur));
                out.put(o);
            }
        } finally {
            if (c != null) c.close();
        }
    }

    // ---------- thumbnails ----------

    @PluginMethod
    public void thumbs(final PluginCall call) {
        final JSArray ids = call.getArray("ids");
        Integer requested = call.getInt("size", 320);
        final int size = requested == null ? 320 : requested.intValue();
        if (ids == null) {
            call.reject("ids");
            return;
        }
        pool.execute(new Runnable() {
            @Override
            public void run() {
                JSArray out = new JSArray();
                for (int i = 0; i < ids.length(); i++) {
                    try {
                        String id = ids.getString(i);
                        String path = makeThumb(id, size);
                        if (path != null) {
                            JSObject o = new JSObject();
                            o.put("id", id);
                            o.put("path", path);
                            out.put(o);
                        }
                    } catch (Exception ignored) {
                    }
                }
                JSObject res = new JSObject();
                res.put("items", out);
                call.resolve(res);
            }
        });
    }

    private Uri uriFor(String id) {
        try {
            boolean video = id.startsWith("v");
            long n = Long.parseLong(id.substring(1));
            Uri base = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
            return ContentUris.withAppendedId(base, n);
        } catch (Exception e) {
            return null;
        }
    }

    private String makeThumb(String id, int size) {
        try {
            boolean video = id.startsWith("v");
            long n = Long.parseLong(id.substring(1));
            File dir = new File(getContext().getCacheDir(), "thumbs");
            if (!dir.exists()) dir.mkdirs();
            File f = new File(dir, id + "_" + size + ".jpg");
            if (f.exists() && f.length() > 0) return f.getAbsolutePath();

            ContentResolver resolver = getContext().getContentResolver();
            Bitmap bmp;
            if (Build.VERSION.SDK_INT >= 29) {
                bmp = resolver.loadThumbnail(uriFor(id), new Size(size, size), null);
            } else {
                bmp = legacyThumb(resolver, video, n);
            }
            if (bmp == null) return null;

            FileOutputStream os = new FileOutputStream(f);
            try {
                bmp.compress(Bitmap.CompressFormat.JPEG, size > 600 ? 88 : 80, os);
            } finally {
                os.close();
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    @SuppressWarnings("deprecation")
    private Bitmap legacyThumb(ContentResolver resolver, boolean video, long n) {
        if (video) {
            return MediaStore.Video.Thumbnails.getThumbnail(resolver, n, MediaStore.Video.Thumbnails.MINI_KIND, null);
        }
        return MediaStore.Images.Thumbnails.getThumbnail(resolver, n, MediaStore.Images.Thumbnails.MINI_KIND, null);
    }

    // ---------- delete ----------

    @PluginMethod
    public void deleteMedia(final PluginCall call) {
        final JSArray ids = call.getArray("ids");
        if (ids == null || ids.length() == 0) {
            call.reject("ids");
            return;
        }
        final List<Uri> uris = new ArrayList<Uri>();
        final List<String> idList = new ArrayList<String>();
        try {
            for (int i = 0; i < ids.length(); i++) {
                String id = ids.getString(i);
                Uri u = uriFor(id);
                if (u != null) {
                    uris.add(u);
                    idList.add(id);
                }
            }
        } catch (Exception e) {
            call.reject("bad_ids");
            return;
        }
        if (uris.isEmpty()) {
            call.reject("ids");
            return;
        }

        if (Build.VERSION.SDK_INT >= 30) {
            // Android shows its own "Allow Kuha Gallery to delete?" prompt.
            try {
                PendingIntent pi = MediaStore.createDeleteRequest(getContext().getContentResolver(), uris);
                final IntentSenderRequest req = new IntentSenderRequest.Builder(pi.getIntentSender()).build();
                pendingDelete = call;
                pendingIds = idList;
                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            deleteLauncher.launch(req);
                        } catch (Exception e) {
                            PluginCall c = pendingDelete;
                            pendingDelete = null;
                            pendingIds = null;
                            if (c != null) c.reject("delete_failed: " + e.getMessage());
                        }
                    }
                });
            } catch (Exception e) {
                pendingDelete = null;
                pendingIds = null;
                call.reject("delete_failed: " + e.getMessage());
            }
        } else {
            pool.execute(new Runnable() {
                @Override
                public void run() {
                    JSArray done = new JSArray();
                    Context ctx = getContext();
                    for (int i = 0; i < uris.size(); i++) {
                        try {
                            if (ctx.getContentResolver().delete(uris.get(i), null, null) > 0) {
                                done.put(idList.get(i));
                            }
                        } catch (Exception ignored) {
                        }
                    }
                    JSObject res = new JSObject();
                    res.put("deleted", done);
                    call.resolve(res);
                }
            });
        }
    }

    private ActivityResultLauncher<IntentSenderRequest> deleteLauncher;
    private PluginCall pendingDelete;
    private List<String> pendingIds;

    @Override
    public void load() {
        // Android 11+ shows its own "Allow Kuha Gallery to delete?" prompt; this receives the answer.
        deleteLauncher = getActivity().registerForActivityResult(
            new ActivityResultContracts.StartIntentSenderForResult(),
            result -> {
                PluginCall call = pendingDelete;
                List<String> ids = pendingIds;
                pendingDelete = null;
                pendingIds = null;
                if (call == null) return;
                JSArray done = new JSArray();
                if (result.getResultCode() == Activity.RESULT_OK && ids != null) {
                    for (String id : ids) done.put(id);
                }
                JSObject res = new JSObject();
                res.put("deleted", done);
                call.resolve(res);
            }
        );
    }
}
