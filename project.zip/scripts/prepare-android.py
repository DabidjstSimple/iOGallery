#!/usr/bin/env python3
"""Run after `npx cap add android`: drops the native Gallery plugin into the
generated Android project and adds the photo/video permissions."""
import pathlib
import re
import shutil
import sys

root = pathlib.Path(__file__).resolve().parent.parent
android = root / "android"
native = root / "native"

mains = list(android.glob("app/src/main/java/**/MainActivity.java"))
if not mains:
    sys.exit("MainActivity.java not found. Did `npx cap add android` run?")
pkg_dir = mains[0].parent
print("Java package folder:", pkg_dir)

for name in ("GalleryPlugin.java", "MainActivity.java"):
    shutil.copy(native / name, pkg_dir / name)
    print("copied", name)

manifest = android / "app/src/main/AndroidManifest.xml"
text = manifest.read_text()
perms = """
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
    <uses-permission android:name="android.permission.READ_MEDIA_VIDEO" />
    <uses-permission android:name="android.permission.READ_MEDIA_VISUAL_USER_SELECTED" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
"""
if "READ_MEDIA_IMAGES" not in text:
    m = re.search(r'<uses-permission[^>]*android\.permission\.INTERNET[^>]*/>', text)
    if m:
        text = text[: m.end()] + perms + text[m.end():]
    else:
        text = text.replace("<application", perms + "\n    <application", 1)
    manifest.write_text(text)
    print("added media permissions to AndroidManifest.xml")
else:
    print("media permissions already present")
